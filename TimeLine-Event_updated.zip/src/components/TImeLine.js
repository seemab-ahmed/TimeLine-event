import React from "react";
import { VerticalTimeline, VerticalTimelineElement } from 'react-vertical-timeline-component';
import 'react-vertical-timeline-component/style.min.css';
import Breathwork from "../assets/breath-work.png";
import maryMalifarges from "../assets/Mary Malifarges.png";

function ProgramSection() {

  const eventsData = [
    {
      startTime: "09:00 AM",
      endTime: "10:00 AM",
      title: "Breathwork With Walid Aboulnaga",
      location: "DOME",
      image: Breathwork,
    },
    {
      startTime: "09:00 AM",
      endTime: "10:30 AM",
      title: "Handpan with Anas",
      location: "Market Place",
      image: maryMalifarges,
    },
    {
      startTime: "10:00 AM",
      endTime: "11:30 AM",
      title: "Anas Handpan Orchestra Workshop",
      location: "DOME",
      image: Breathwork,
    },
  ];

  // Helper function to convert time into a 24-hour format
  const convertTo24Hour = (time) => {
    const [hour, minute, period] = time.split(/[:\s]/);
    let hours = parseInt(hour);
    if (period === "PM" && hours !== 12) {
      hours += 12;
    } else if (period === "AM" && hours === 12) {
      hours = 0;
    }
    return `${hours}:${minute}`;
  };

  // Function to check if two events overlap by checking start time
  const checkOverlap = (event1, event2) => {
    return event1?.startTime === event2?.startTime;
  };

  return (
    <section className="program-section">
      <div className="container">
        <VerticalTimeline>
          {eventsData.map((event, index) => (
            <VerticalTimelineElement
              key={index}
              className={`element ${checkOverlap(eventsData[index], eventsData[index - 1]) ? 'overlap' : ''}`}
              date={`${convertTo24Hour(event.startTime)} - ${convertTo24Hour(event.endTime)}`}
              iconStyle={{ background: 'rgb(33, 150, 243)', color: '#fff' }}
              contentStyle={{ marginLeft: checkOverlap(eventsData[index], eventsData[index - 1]) ? '150px' : '' }}
            >
              <h3 className="inner-title">{event.title}</h3>
              <h4 className="inner-subtitle">{event.location}</h4>
              {event.image && (
                <img 
                  src={event.image} 
                  alt={event.title} 
                  style={{ width: '100px', height: '100px', objectFit: 'cover' }}
                />
              )}
            </VerticalTimelineElement>
          ))}
        </VerticalTimeline>
      </div>
    </section>
  );
}

export default ProgramSection;
