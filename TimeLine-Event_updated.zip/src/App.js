import React from 'react';
import './App.css';
// import ProgramSection from './components/ProgramSection';
import ProgramSection from './components/ProgramSection_update_One';
// import ProgramSection from './components/TImeLine';

function App() {

  return (
    <>
    <ProgramSection/>
    </>
  );
}

export default App;
